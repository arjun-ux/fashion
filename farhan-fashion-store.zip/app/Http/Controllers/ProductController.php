<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use App\Models\Kategori;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\QueryException;

class ProductController extends Controller
{
    public function index()
    {
        return view('admin.produk.index', [
            'produk' => Produk::with('kategori')->get(),
            'title' => 'Kelola Produk'
        ]);
    }

    public function create()
    {
        $kategori = Kategori::all();
        return view('admin.produk.create', compact('kategori'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'harga' => 'required|numeric',
            'stok' => 'required|integer',
            'kategori_id' => 'required|exists:kategoris,id',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($request->hasFile('gambar')) {
            $gambar = $request->file('gambar');
            $nama_file = time()."_".$gambar->getClientOriginalName();
            $gambar->move(public_path('images/produk'), $nama_file);
            $gambarPath = 'images/produk/' . $nama_file;
        }

        Produk::create([
            'nama' => $request->nama,
            'harga' => $request->harga,
            'stok' => $request->stok,
            'kategori_id' => $request->kategori_id,
            'gambar' => $gambarPath ?? null,
        ]);

        return redirect()->route('admin.produk.index')->with('success', 'Produk berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $produk = Produk::findOrFail($id);
        $kategori = Kategori::all();
        return view('admin.produk.edit', compact('produk', 'kategori'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nama' => 'required',
            'harga' => 'required|numeric',
            'stok' => 'required|integer',
            'kategori_id' => 'required|exists:kategoris,id',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $produk = Produk::findOrFail($id);

        if ($request->hasFile('gambar')) {
            // Hapus gambar lama
            if($produk->gambar && file_exists(public_path($produk->gambar))) {
                unlink(public_path($produk->gambar));
            }
            
            // Upload gambar baru
            $gambar = $request->file('gambar');
            $nama_file = time()."_".$gambar->getClientOriginalName();
            $gambar->move(public_path('images/produk'), $nama_file);
            $gambarPath = 'images/produk/' . $nama_file;
            
            $produk->gambar = $gambarPath;
        }

        $produk->update([
            'nama' => $request->nama,
            'harga' => $request->harga,
            'stok' => $request->stok,
            'kategori_id' => $request->kategori_id
        ]);

        return redirect()->route('admin.produk.index')->with('success', 'Produk berhasil diupdate');
    }

    public function destroy($id)
    {
        try {
            $produk = Produk::findOrFail($id);
            
            // Check if there are any related orders
            $hasOrders = Order::where('product_id', $id)->exists();
            
            if ($hasOrders) {
                return redirect()
                    ->route('admin.produk.index')
                    ->with('error', 'Produk tidak dapat dihapus karena masih terdapat transaksi terkait. Pertimbangkan untuk menonaktifkan produk ini sebagai gantinya.');
            }

            // If no orders exist, proceed with deletion
            if ($produk->gambar && file_exists(public_path($produk->gambar))) {
                unlink(public_path($produk->gambar));
            }

            $produk->delete();
            return redirect()
                ->route('admin.produk.index')
                ->with('success', 'Produk berhasil dihapus');

        } catch (QueryException $e) {
            // Log the error for debugging
            \Log::error('Error deleting product:', [
                'product_id' => $id,
                'error' => $e->getMessage()
            ]);

            return redirect()
                ->route('admin.produk.index')
                ->with('error', 'Tidak dapat menghapus produk karena masih terdapat data terkait.');
        } catch (\Exception $e) {
            \Log::error('Unexpected error while deleting product:', [
                'product_id' => $id,
                'error' => $e->getMessage()
            ]);

            return redirect()
                ->route('admin.produk.index')
                ->with('error', 'Terjadi kesalahan saat menghapus produk.');
        }
    }

    public function search(Request $request)
    {
        $query = $request->get('q');
        
        $products = Produk::where('nama', 'like', "%{$query}%")
            ->where('stok', '>', 0)
            ->select('id', 'nama', 'harga', 'stok')
            ->get();

        return response()->json($products);
    }
}
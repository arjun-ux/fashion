<?php

namespace App\Http\Controllers;

use App\Models\Order; 
use App\Models\Produk;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class OrderController extends Controller 
{
    public function index()
    {
        $products = Produk::where('stok', '>', 0)->get();
        $orders = Order::with('produk')->latest()->take(10)->get();
        return view('kasir.penjualan.index', compact('products', 'orders'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'customer_name' => 'required',
            'product_name' => 'required',
            'quantity' => 'required|integer|min:1',
            'price' => 'required|numeric',
            'total_price' => 'required|numeric'
        ]);

        $product = Produk::where('nama', $request->product_name)->firstOrFail();

        if($product->stok < $request->quantity) {
            return back()->with('error', 'Stok tidak mencukupi');
        }

        $order = Order::create([
            'customer_name' => $request->customer_name,
            'product_id' => $product->id,
            'product_name' => $request->product_name,
            'quantity' => $request->quantity,
            'price' => $request->price,
            'total_price' => $request->total_price,
            'payment_status' => 'paid'
        ]);

        $product->update([
            'stok' => $product->stok - $request->quantity
        ]);

        return redirect()->route('order.print', $order->id);
    }

    // Sesuaikan dengan route /orders/{order}/edit
    public function edit($id)
    {
        $order = Order::findOrFail($id);
        return response()->json($order);
    }

    public function update(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        
        $request->validate([
            'customer_name' => 'required',
            'product_id' => 'required|exists:products,id', // Ubah dari produks ke products
            'quantity' => 'required|integer|min:1',
            'price' => 'required|numeric',
            'total_price' => 'required|numeric',
            'payment_status' => 'required|in:paid,unpaid'
        ]);
    
        // ... rest of the code

        $oldProduct = Produk::findOrFail($order->product_id);
        $newProduct = Produk::findOrFail($request->product_id);

        $oldProduct->update([
            'stok' => $oldProduct->stok + $order->quantity
        ]);

        $newProduct->update([
            'stok' => $newProduct->stok - $request->quantity
        ]);

        $order->update([
            'customer_name' => $request->customer_name,
            'product_id' => $request->product_id,
            'quantity' => $request->quantity,
            'price' => $request->price,
            'total_price' => $request->total_price,
            'payment_status' => $request->payment_status
        ]);

        return redirect()->back()->with('success', 'Transaksi berhasil diupdate');
    }

    // Sesuaikan dengan route /orders/{order}
    public function destroy($id)
    {
        $order = Order::findOrFail($id);
        $product = Produk::findOrFail($order->product_id);
        
        $product->update([
            'stok' => $product->stok + $order->quantity
        ]);

        $order->delete();
        return redirect()->back()->with('success', 'Transaksi berhasil dihapus');
    }

    public function history()
    {
        $orders = Order::with('produk')->latest()->paginate(10);
        return view('kasir.orders.history', compact('orders'));
    }

    public function print($id)
    {
        $order = Order::with('produk')->findOrFail($id);
        $pdf = PDF::loadView('kasir.orders.receipt', compact('order'));
        return $pdf->stream('receipt-'.$order->id.'.pdf');
    }
}
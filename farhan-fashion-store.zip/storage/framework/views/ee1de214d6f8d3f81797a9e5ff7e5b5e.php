<div>
    <!-- Knowing is not enough; we must apply. Being willing is not enough; we must do. - Leonardo da Vinci -->
</div><?php /**PATH C:\laragon\www\farhan-fashion-store\resources\views\components\alert.blade.php ENDPATH**/ ?>
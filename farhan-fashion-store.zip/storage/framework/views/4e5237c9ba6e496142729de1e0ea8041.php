<!-- resources/views/owner/laporan/penjualan.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-lg shadow p-6">
    <div class="mb-6 flex justify-between items-center">
        <h3 class="text-lg font-semibold">Filter Laporan Penjualan</h3>
        
        <form action="<?php echo e(route('owner.laporan.penjualan')); ?>" method="GET" class="flex gap-4">
            <select name="period" class="rounded border-gray-300">
                <option value="all" <?php echo e(request('period') == 'all' ? 'selected' : ''); ?>>Semua</option>
                <option value="daily" <?php echo e(request('period') == 'daily' ? 'selected' : ''); ?>>Hari Ini</option>
                <option value="monthly" <?php echo e(request('period') == 'monthly' ? 'selected' : ''); ?>>Bulan Ini</option>
                <option value="yearly" <?php echo e(request('period') == 'yearly' ? 'selected' : ''); ?>>Tahun Ini</option>
                <option value="custom" <?php echo e(request('period') == 'custom' ? 'selected' : ''); ?>>Custom</option>
            </select>
            
            <div class="custom-date <?php echo e(request('period') == 'custom' ? '' : 'hidden'); ?>">
                <input type="date" name="start_date" value="<?php echo e(request('start_date')); ?>" class="rounded border-gray-300">
                <input type="date" name="end_date" value="<?php echo e(request('end_date')); ?>" class="rounded border-gray-300">
            </div>
            
            <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded">Filter</button>
            <button type="submit" name="export" value="1" class="px-4 py-2 bg-green-500 text-white rounded">
                <i class="fas fa-download mr-2"></i> Export PDF
            </button>
        </form>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full">
            <thead>
                <tr class="bg-gray-50">
                    <th class="px-4 py-2 text-left">Tanggal</th>
                    <th class="px-4 py-2 text-left">Produk</th>
                    <th class="px-4 py-2 text-left">Customer</th>
                    <th class="px-4 py-2 text-right">Qty</th>
                    <th class="px-4 py-2 text-right">Harga</th>
                    <th class="px-4 py-2 text-right">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t">
                    <td class="px-4 py-2"><?php echo e($order->created_at->format('d/m/Y H:i')); ?></td>
                    <td class="px-4 py-2"><?php echo e($order->produk->nama ?? "Produk Tidak ada"); ?></td>
                    <td class="px-4 py-2"><?php echo e($order->customer_name); ?></td>
                    <td class="px-4 py-2 text-right"><?php echo e($order->quantity); ?></td>
                    <td class="px-4 py-2 text-right">Rp <?php echo e(number_format($order->price)); ?></td>
                    <td class="px-4 py-2 text-right">Rp <?php echo e(number_format($order->total_price)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr class="border-t">
                    <td colspan="5" class="px-4 py-2 font-bold text-right">Total Penjualan:</td>
                    <td class="px-4 py-2 font-bold text-right">Rp <?php echo e(number_format($total)); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.querySelector('select[name="period"]').addEventListener('change', function() {
    const customDate = document.querySelector('.custom-date');
    if (this.value === 'custom') {
        customDate.classList.remove('hidden');
    } else {
        customDate.classList.add('hidden');
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.owner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\farhan-fashion-store\resources\views\owner\laporan\penjualan.blade.php ENDPATH**/ ?>
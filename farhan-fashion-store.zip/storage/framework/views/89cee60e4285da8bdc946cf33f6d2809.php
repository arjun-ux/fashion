

<?php $__env->startSection('content'); ?>
<div class="py-12 min-h-screen w-full relative">
    <div class="absolute inset-0 bg-[#0F172A]/95 z-0"></div>
    <div class="absolute inset-0 bg-[url('https://images.pexels.com/photos/29625971/pexels-photo-29625971.jpeg')] bg-center bg-cover opacity-10"></div>

    <div class="relative z-10 w-full px-4 sm:px-6 lg:px-8">
        <?php if(session('success')): ?>
        <div class="bg-red-500/20 border border-red-500/50 text-red-500 px-4 py-3 rounded-lg mb-4 backdrop-blur-sm animate-fade-in">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <div class="backdrop-blur-md bg-gray-900/80 overflow-hidden shadow-2xl rounded-lg border border-red-500/30">
            <div class="p-6">
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                    <h2 class="text-2xl font-bold text-red-500">Manage Users</h2>
                    
                    <div class="flex flex-wrap gap-2">
                        <div class="flex flex-wrap gap-2">
                            <form action="<?php echo e(route('admin.reports.pdf')); ?>" method="GET" class="group">
                                <input type="hidden" name="period" value="daily">
                                <button type="submit" class="px-4 py-2 bg-gray-800 hover:bg-red-500/20 border border-red-500/30 group-hover:border-red-500/50 rounded-lg transition-all duration-300 flex items-center gap-2">
                                    <i class="fas fa-file-pdf text-red-500"></i>
                                    <span class="text-red-500">Daily Report</span>
                                </button>
                            </form>
                            
                            <form action="<?php echo e(route('admin.reports.pdf')); ?>" method="GET" class="group">
                                <input type="hidden" name="period" value="monthly">
                                <button type="submit" class="px-4 py-2 bg-gray-800 hover:bg-red-500/20 border border-red-500/30 group-hover:border-red-500/50 rounded-lg transition-all duration-300 flex items-center gap-2">
                                    <i class="fas fa-file-pdf text-red-500"></i>
                                    <span class="text-red-500">Monthly Report</span>
                                </button>
                            </form>
                            
                            <form action="<?php echo e(route('admin.reports.pdf')); ?>" method="GET" class="group">
                                <input type="hidden" name="period" value="yearly">
                                <button type="submit" class="px-4 py-2 bg-gray-800 hover:bg-red-500/20 border border-red-500/30 group-hover:border-red-500/50 rounded-lg transition-all duration-300 flex items-center gap-2">
                                    <i class="fas fa-file-pdf text-red-500"></i>
                                    <span class="text-red-500">Yearly Report</span>
                                </button>
                            </form>
                        </div>

                        <a href="<?php echo e(route('admin.pengguna.create')); ?>" 
                           class="px-6 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-all duration-300 flex items-center gap-2 shadow-lg hover:shadow-red-500/20">
                            <i class="fas fa-plus"></i>
                            <span>Add New User</span>
                        </a>
                    </div>
                </div>

                <div class="overflow-x-auto rounded-lg border border-red-500/20">
                    <table class="w-full text-left">
                        <thead>
                            <tr class="bg-gray-800/50">
                                <th class="px-6 py-3 text-red-500 font-semibold">Name</th>
                                <th class="px-6 py-3 text-red-500 font-semibold">Email</th>
                                <th class="px-6 py-3 text-red-500 font-semibold">Role</th>
                                <th class="px-6 py-3 text-red-500 font-semibold">Created At</th>
                                <th class="px-6 py-3 text-center text-red-500 font-semibold">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-t border-red-500/10 hover:bg-red-500/5 transition-colors">
                                <td class="px-6 py-4 text-gray-200"><?php echo e($user->name); ?></td>
                                <td class="px-6 py-4 text-gray-200"><?php echo e($user->email); ?></td>
                                <td class="px-6 py-4">
                                    <span class="px-3 py-1 rounded-full text-sm
                                        <?php if($user->usertype === 'admin'): ?> bg-red-500/20 text-red-500
                                        <?php elseif($user->usertype === 'owner'): ?> bg-red-500/20 text-red-500
                                        <?php else: ?> bg-red-500/20 text-red-500
                                        <?php endif; ?>">
                                        <?php echo e(ucfirst($user->usertype)); ?>

                                    </span>
                                </td>
                                <td class="px-6 py-4 text-gray-200"><?php echo e($user->created_at->format('d M Y')); ?></td>
                                <td class="px-6 py-4">
                                    <div class="flex justify-center gap-2">
                                        <a href="<?php echo e(route('admin.pengguna.edit', $user->id)); ?>" 
                                           class="p-2 bg-gray-800 hover:bg-red-500/20 rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-red-500/10">
                                            <i class="fas fa-edit text-red-500"></i>
                                        </a>
                                        
                                        <form action="<?php echo e(route('admin.pengguna.destroy', $user->id)); ?>" 
                                              method="POST" 
                                              onsubmit="return confirm('Are you sure you want to delete this user?');" 
                                              class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" 
                                                    class="p-2 bg-gray-800 hover:bg-red-500/20 rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-red-500/10">
                                                <i class="fas fa-trash text-red-500"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.animate-fade-in {
    animation: fadeIn 0.5s ease-in;
}

@keyframes fadeIn {
    0% { opacity: 0; transform: translateY(-10px); }
    100% { opacity: 1; transform: translateY(0); }
}

@keyframes glow {
    0% { box-shadow: 0 0 5px rgb(239 68 68 / 0.2), 0 0 10px rgb(239 68 68 / 0.2); }
    100% { box-shadow: 0 0 10px rgb(239 68 68 / 0.3), 0 0 20px rgb(239 68 68 / 0.3); }
}

.hover\:glow:hover {
    animation: glow 1.5s infinite alternate;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\farhan-fashion-store\resources\views/admin/pengguna/index.blade.php ENDPATH**/ ?>
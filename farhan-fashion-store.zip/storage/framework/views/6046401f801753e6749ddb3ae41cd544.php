
<!-- resources/views/owner/reports/penjualan-pdf.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan Penjualan</title>
    <style>
        body { font-family: Arial, sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f8f9fa; }
        .header { margin-bottom: 30px; }
        .total { margin-top: 20px; text-align: right; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Laporan Penjualan</h1>
        <p>Periode: <?php echo e(ucfirst($period)); ?></p>
        <p>Tanggal Cetak: <?php echo e(now()->format('d/m/Y H:i')); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Produk</th>
                <th>Customer</th>
                <th style="text-align: right">Qty</th>
                <th style="text-align: right">Harga</th>
                <th style="text-align: right">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t">
                    <td class="px-4 py-2"><?php echo e($order->created_at->format('d/m/Y H:i')); ?></td>
                    <td class="px-4 py-2"><?php echo e($order->produk->nama ?? "Produk Tidak ada"); ?></td>
                    <td class="px-4 py-2"><?php echo e($order->customer_name); ?></td>
                    <td class="px-4 py-2 text-right"><?php echo e($order->quantity); ?></td>
                    <td class="px-4 py-2 text-right">Rp <?php echo e(number_format($order->price)); ?></td>
                    <td class="px-4 py-2 text-right">Rp <?php echo e(number_format($order->total_price)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="total">
        <p>Total Penjualan: Rp <?php echo e(number_format($total)); ?></p>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\farhan-fashion-store\resources\views\owner\reports\penjualan-pdf.blade.php ENDPATH**/ ?>
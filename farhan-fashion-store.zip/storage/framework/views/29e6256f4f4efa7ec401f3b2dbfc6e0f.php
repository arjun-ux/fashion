<!-- kasir/produk/index.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <div class="bg-zinc-900/80 backdrop-blur-sm rounded-xl shadow-lg p-6 border border-pink-500/20">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center text-pink-400">
                    <i class="fas fa-box w-6 h-6 mr-2"></i>
                    <h1 class="text-xl font-semibold neon-glow">DAFTAR PRODUK</h1>
                </div>
            </div>

            <div class="bg-zinc-800/50 rounded-lg shadow-md">
                <div class="p-4">
                    <div class="flex justify-between items-center mb-4">
                        <div class="flex items-center text-gray-300">
                            <span>Show</span>
                            <select class="mx-2 bg-zinc-900 border border-pink-500/20 rounded px-2 py-1 focus:border-pink-500/50 transition-colors" id="showEntries">
                                <?php $__currentLoopData = [10, 25, 50]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span>entries</span>
                        </div>
                        <div class="flex items-center">
                            <span class="mr-2 text-gray-300">Search:</span>
                            <input type="text" id="searchInput" 
                                   class="bg-zinc-900 border border-pink-500/20 rounded px-2 py-1 text-gray-300 focus:border-pink-500/50 transition-colors" 
                                   placeholder="Search...">
                        </div>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="min-w-full border border-pink-500/20">
                            <thead>
                                <tr class="bg-zinc-800/80">
                                    <th class="border border-pink-500/20 px-4 py-2 text-left text-gray-300">ID Produk</th>
                                    <th class="border border-pink-500/20 px-4 py-2 text-left text-gray-300">Nama</th>
                                    <th class="border border-pink-500/20 px-4 py-2 text-left text-gray-300">Harga</th>
                                    <th class="border border-pink-500/20 px-4 py-2 text-left text-gray-300">Stok</th>
                                    <th class="border border-pink-500/20 px-4 py-2 text-left text-gray-300">Kategori</th>
                                    <th class="border border-pink-500/20 px-4 py-2 text-left text-gray-300">Gambar</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-pink-500/10">
                                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-zinc-800/50 transition-colors">
                                    <td class="border border-pink-500/20 px-4 py-2 text-gray-300"><?php echo e($item->id); ?></td>
                                    <td class="border border-pink-500/20 px-4 py-2 text-gray-300"><?php echo e($item->nama); ?></td>
                                    <td class="border border-pink-500/20 px-4 py-2 text-gray-300">Rp <?php echo e(number_format($item->harga, 0, ',', '.')); ?></td>
                                    <td class="border border-pink-500/20 px-4 py-2">
                                        <span class="px-2 py-1 rounded text-sm
                                            <?php if($item->stok > 10): ?> text-green-400
                                            <?php elseif($item->stok > 0): ?> text-yellow-400
                                            <?php else: ?> text-red-400
                                            <?php endif; ?>">
                                            <?php echo e($item->stok); ?>

                                        </span>
                                    </td>
                                    <td class="border border-pink-500/20 px-4 py-2 text-gray-300"><?php echo e($item->kategori->nama_kategori); ?></td>
                                    <td class="border border-pink-500/20 px-4 py-2">
                                        <?php if($item->gambar): ?>
                                            <img src="<?php echo e(asset($item->gambar)); ?>" 
                                                 alt="<?php echo e($item->nama); ?>" 
                                                 class="h-12 w-12 object-cover rounded">
                                        <?php else: ?>
                                            <div class="h-12 w-12 bg-zinc-800 flex items-center justify-center rounded">
                                                <i class="fas fa-image text-zinc-600"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $("#searchInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("table tbody tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });

    $("#showEntries").on("change", function() {
        var value = parseInt($(this).val());
        var rows = $("table tbody tr").length;
        
        $("table tbody tr").hide();
        $("table tbody tr").slice(0, Math.min(value, rows)).show();
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.kasir-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\farhan-fashion-store\resources\views\kasir\produk\index.blade.php ENDPATH**/ ?>
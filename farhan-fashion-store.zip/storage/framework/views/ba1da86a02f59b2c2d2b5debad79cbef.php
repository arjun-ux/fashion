<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo e($title); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo {
            width: 150px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #DAA520;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .meta-info {
            margin-bottom: 20px;
        }
        .footer {
            margin-top: 30px;
            text-align: right;
            font-style: italic;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            background-color: #DAA520;
            color: white;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?php echo e($title); ?></h1>
    </div>

    <div class="meta-info">
        <p><strong>Tanggal Cetak:</strong> <?php echo e(now()->format('d/m/Y H:i:s')); ?></p>
        <p><strong>Dicetak Oleh:</strong> <?php echo e(auth()->user()->name); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Role</th>
                <th>Tanggal Dibuat</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <div class="status-badge">
                        <?php echo e(ucfirst($user->usertype)); ?>

                    </div>
                </td>
                <td><?php echo e($user->created_at->format('d/m/Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="footer">
        <p><strong>Total Users:</strong> <?php echo e($users->count()); ?></p>
        <p>Laporan ini digenerate secara otomatis oleh sistem</p>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\farhan-fashion-store\resources\views\reports\users.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- CSS Styling -->
    <style>
        /* General Layout */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .layout-container {
            display: flex;
            min-height: 100vh;
            width: 100vw;
            font-family: Arial, sans-serif;
            overflow: hidden;
        }

        /* Semua CSS yang sudah Anda buat sebelumnya */
    </style>

    <!-- Layout Container -->
    <div class="layout-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>FARHAN FASHION STORE</h2>
                <span class="admin-badge">ADMIN</span>
            </div>
            
            <div class="sidebar-menu">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="menu-item">
                    <span class="menu-icon">📊</span>Dashboard
                </a>
                <a href="#" class="menu-item">
                    <span class="menu-icon">📥</span>Input
                </a>
                <div class="submenu">
                    <a href="<?php echo e(route('admin.users')); ?>" class="menu-item">
                        <span class="menu-icon">👥</span>Kelola Pengguna
                    </a>
                    <a href="<?php echo e(route('admin.products')); ?>" class="menu-item">
                        <span class="menu-icon">👕</span>Kelola Produk
                    </a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header-bar">
                BERANDA
            </div>

            <div class="card-container">
                <div class="card">
                    <div class="card-content">
                        <div class="card-number"><?php echo e($productCount); ?></div>
                        <div class="card-label">Product</div>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('admin.products')); ?>">Selengkapnya</a>
                    </div>
                </div>

                <div class="card">
                    <div class="card-content">
                        <div class="card-number"><?php echo e($userCount); ?></div>
                        <div class="card-label">User</div>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('admin.users')); ?>">Selengkapnya</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\farhan-fashion-store\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>